/**
 * Free Blocker — Dashboard Script
 * Renders blocking statistics and charts.
 */

import { themeManager } from '../../components/theme.js';
import { formatNumber } from '../../utils/helpers.js';

document.addEventListener('DOMContentLoaded', async () => {
  await themeManager.initialize();

  /* Elements */
  const statTotalAds = document.getElementById('stat-total-ads');
  const statTodayAds = document.getElementById('stat-today-ads');
  const statTrackers = document.getElementById('stat-trackers');
  const statScore = document.getElementById('stat-score');
  const scoreBar = document.getElementById('score-bar');
  
  const statMalware = document.getElementById('stat-malware');
  const statPhishing = document.getElementById('stat-phishing');
  const statScam = document.getElementById('stat-scam');
  const statAdult = document.getElementById('stat-adult');
  
  const chartContainer = document.getElementById('distribution-chart');

  /* Navigation */
  document.getElementById('btn-back-popup').addEventListener('click', () => {
    window.location.href = '../../popup/popup.html';
  });

  /* Render */
  await renderDashboard();

  async function renderDashboard() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
      const stats = res?.stats || {};

      /* Update Top Stats */
      animateValue(statTotalAds, 0, stats.adsBlockedTotal || 0, 1000);
      statTodayAds.textContent = `+${formatNumber(stats.adsBlockedToday || 0)}`;
      animateValue(statTrackers, 0, stats.trackersBlocked || 0, 1000);
      
      /* Update Score */
      const score = stats.performanceScore || 100;
      animateValue(statScore, 0, score, 1000);
      scoreBar.style.width = '0%';
      setTimeout(() => {
        scoreBar.style.transition = 'width 1s ease-out';
        scoreBar.style.width = `${score}%`;
        
        /* Color logic */
        if (score >= 90) {
          scoreBar.className = 'h-1.5 rounded-full bg-emerald-500';
          statScore.className = 'text-4xl font-bold text-emerald-500';
        } else if (score >= 70) {
          scoreBar.className = 'h-1.5 rounded-full bg-amber-500';
          statScore.className = 'text-4xl font-bold text-amber-500';
        } else {
          scoreBar.className = 'h-1.5 rounded-full bg-rose-500';
          statScore.className = 'text-4xl font-bold text-rose-500';
        }
      }, 100);

      /* Update Detail Stats */
      statMalware.textContent = formatNumber(stats.malwareBlocked || 0);
      statPhishing.textContent = formatNumber(stats.phishingBlocked || 0);
      statScam.textContent = formatNumber(stats.scamsBlocked || 0);
      statAdult.textContent = formatNumber(stats.adultSitesBlocked || 0);

      /* Render Chart */
      renderChart(stats);

    } catch (error) {
      console.error('Failed to render dashboard', error);
    }
  }

  function renderChart(stats) {
    const data = [
      { label: 'Advertisements', value: stats.adsBlockedTotal || 0, color: 'bg-indigo-500' },
      { label: 'Trackers & Analytics', value: stats.trackersBlocked || 0, color: 'bg-violet-500' },
      { label: 'Popups', value: stats.popupsBlocked || 0, color: 'bg-blue-500' },
      { label: 'Malware & Phishing', value: (stats.malwareBlocked || 0) + (stats.phishingBlocked || 0), color: 'bg-rose-500' },
      { label: 'Scams', value: stats.scamsBlocked || 0, color: 'bg-amber-500' },
      { label: 'Adult Content', value: stats.adultSitesBlocked || 0, color: 'bg-pink-500' }
    ];

    /* Sort by value descending */
    data.sort((a, b) => b.value - a.value);
    
    /* Calculate max for percentage */
    const max = Math.max(...data.map(d => d.value), 1);

    chartContainer.innerHTML = '';
    
    let hasData = false;

    data.forEach(item => {
      if (item.value > 0) hasData = true;
      
      const percent = Math.max((item.value / max) * 100, 1); // min 1% for visibility
      
      const row = document.createElement('div');
      
      row.innerHTML = `
        <div class="flex justify-between text-sm mb-1">
          <span class="font-medium text-slate-700 dark:text-slate-300">${item.label}</span>
          <span class="text-slate-500 dark:text-slate-400">${item.value.toLocaleString()}</span>
        </div>
        <div class="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2">
          <div class="${item.color} h-2 rounded-full animate-bar" style="--target-width: ${item.value > 0 ? percent : 0}%"></div>
        </div>
      `;
      
      chartContainer.appendChild(row);
    });

    if (!hasData) {
      chartContainer.innerHTML = `
        <div class="text-center py-8">
          <div class="text-4xl mb-3">🌱</div>
          <h4 class="text-slate-900 dark:text-white font-medium">Clean Slate</h4>
          <p class="text-slate-500 dark:text-slate-400 text-sm mt-1">Free Blocker is active, but hasn't blocked anything yet.</p>
        </div>
      `;
    }
  }

  /**
   * Helper to animate number counting
   */
  function animateValue(obj, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      /* Easing out quint */
      const easeProgress = 1 - Math.pow(1 - progress, 5); 
      const current = Math.floor(easeProgress * (end - start) + start);
      obj.innerHTML = current.toLocaleString();
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        obj.innerHTML = formatNumber(end); // Final format uses K/M suffixes for huge numbers
      }
    };
    window.requestAnimationFrame(step);
  }
});
