/**
 * Free Blocker — Popup Script
 * Manages the popup UI, feature toggles, and statistics display.
 */

import { FEATURE_META, FEATURES } from '../utils/constants.js';
import { CardComponent } from '../components/card.js';
import { themeManager } from '../components/theme.js';
import { formatNumber } from '../utils/helpers.js';

document.addEventListener('DOMContentLoaded', async () => {
  /* Initialize theme */
  await themeManager.initialize();

  /* Elements */
  const featuresContainer = document.getElementById('features-container');
  const statBlockedToday = document.getElementById('stat-blocked-today');
  const statBlockedTotal = document.getElementById('stat-blocked-total');
  const globalStatusIndicator = document.getElementById('global-status-indicator');
  const globalStatusText = document.getElementById('global-status-text');

  /* Navigation Buttons */
  document.getElementById('btn-settings').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById('btn-dashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: 'pages/dashboard/dashboard.html' });
  });

  document.getElementById('btn-earnings').addEventListener('click', () => {
    chrome.tabs.create({ url: 'pages/earnings/earnings.html' });
  });

  /* Render */
  await renderPopup();

  /**
   * Category definitions with SVG icons
   */
  const CATEGORIES = [
    {
      id: 'blocking',
      name: 'Ad & Content Blocking',
      icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12Z"></path>'
    },
    {
      id: 'security',
      name: 'Security Protection',
      icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25Z"></path>'
    },
    {
      id: 'privacy',
      name: 'Privacy & Tracking',
      icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0Z"></path>'
    },
    {
      id: 'content',
      name: 'Content Filter',
      icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"></path>'
    }
  ];

  /* Features to hide from popup (managed only in Settings page) */
  const HIDDEN_FEATURES = [
    FEATURES.AUTO_FILTER_UPDATE,
    FEATURES.WHITELIST_MANAGER,
    FEATURES.BLACKLIST_MANAGER,
    FEATURES.STATISTICS_DASHBOARD,
    FEATURES.PERFORMANCE_MONITOR,
    FEATURES.NOTIFICATION_MANAGER
  ];

  /**
   * Render the entire popup UI
   */
  async function renderPopup() {
    try {
      const [featuresRes, statsRes] = await Promise.all([
        chrome.runtime.sendMessage({ type: 'GET_FEATURES' }),
        chrome.runtime.sendMessage({ type: 'GET_STATS' })
      ]);

      const features = featuresRes?.features || {};
      const stats = statsRes?.stats || {};

      updateStatsBanner(stats);
      updateGlobalStatus(features);

      featuresContainer.innerHTML = '';

      for (const category of CATEGORIES) {
        const categoryItems = Object.entries(FEATURE_META).filter(([id, meta]) => {
          return meta.category === category.id && !HIDDEN_FEATURES.includes(id);
        });

        if (categoryItems.length === 0) continue;

        /* Category wrapper */
        const section = document.createElement('div');
        section.className = 'category-section';

        /* Category header */
        const header = document.createElement('div');
        header.className = 'category-header';
        header.innerHTML = `
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">${category.icon}</svg>
          <span class="category-title">${category.name}</span>
        `;
        section.appendChild(header);

        /* Cards grid */
        const grid = document.createElement('div');
        grid.className = 'cards-grid';

        for (const [id, meta] of categoryItems) {
          const isEnabled = features[id] === true;
          const card = CardComponent.create({
            id,
            name: meta.name,
            description: meta.description,
            icon: meta.icon,
            enabled: isEnabled,
            onToggle: handleToggle
          });
          grid.appendChild(card);
        }

        section.appendChild(grid);
        featuresContainer.appendChild(section);
      }

    } catch (error) {
      console.error('Failed to render popup:', error);
      featuresContainer.innerHTML = `
        <div class="error-message">
          <h3>Failed to connect to extension core</h3>
          <p>Please open this from the Extension Icon in your browser toolbar, not as a direct file.</p>
        </div>
      `;
    }
  }

  /**
   * Handle feature toggle
   */
  async function handleToggle(featureId, enabled) {
    try {
      await chrome.runtime.sendMessage({
        type: 'TOGGLE_FEATURE',
        data: { featureId, enabled }
      });

      const res = await chrome.runtime.sendMessage({ type: 'GET_FEATURES' });
      if (res && res.features) {
        updateGlobalStatus(res.features);
      }
    } catch (error) {
      console.error(`Failed to toggle ${featureId}:`, error);
    }
  }

  /**
   * Update stats banner numbers
   */
  function updateStatsBanner(stats) {
    if (statBlockedToday) statBlockedToday.textContent = formatNumber(stats.adsBlockedToday || 0);
    if (statBlockedTotal) statBlockedTotal.textContent = formatNumber(stats.adsBlockedTotal || 0);
  }

  /**
   * Update global protection status indicator
   */
  function updateGlobalStatus(features) {
    const isProtected = features[FEATURES.ALL_ADS_BLOCK] || features[FEATURES.TRACKING_PROTECTION];

    if (isProtected) {
      globalStatusIndicator.className = 'status-dot active';
      globalStatusText.className = 'status-label active';
      globalStatusText.innerHTML = '<span class="pulse-dot"></span> Protection Active';
    } else {
      globalStatusIndicator.className = 'status-dot inactive';
      globalStatusText.className = 'status-label inactive';
      globalStatusText.innerHTML = '<span class="pulse-dot" style="background:var(--danger);animation:none;"></span> Protection Disabled';
    }
  }
});
