import { createElement } from '../utils/helpers.js';

export class CardComponent {
  static create({ id, name, description, icon, enabled = false, onToggle }) {
    const card = createElement('div', { className: 'feature-card' });
    card.dataset.featureId = id;

    /* Top: icon + text */
    const top = createElement('div', { className: 'card-top' });

    const iconWrap = createElement('div', { className: `card-icon ${enabled ? 'on' : 'off'}` });
    iconWrap.innerHTML = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">${icon}</svg>`;

    const textWrap = createElement('div', { className: 'card-text' });
    textWrap.appendChild(createElement('div', { className: 'card-name' }, name));
    textWrap.appendChild(createElement('div', { className: 'card-desc' }, description));

    top.appendChild(iconWrap);
    top.appendChild(textWrap);

    /* Bottom: action button */
    let currentState = enabled;

    const btn = createElement('button', { className: `toggle-btn ${currentState ? 'on' : 'off'}` });

    function updateBtn() {
      if (currentState) {
        btn.className = 'toggle-btn on';
        btn.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg> Enabled`;
        iconWrap.className = 'card-icon on';
      } else {
        btn.className = 'toggle-btn off';
        btn.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg> Disabled`;
        iconWrap.className = 'card-icon off';
      }
    }

    updateBtn();

    btn.addEventListener('click', () => {
      currentState = !currentState;
      updateBtn();
      if (typeof onToggle === 'function') onToggle(id, currentState);
    });

    card.appendChild(top);
    card.appendChild(btn);

    return card;
  }
}
